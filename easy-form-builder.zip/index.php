<?php
/** Silence is golden */